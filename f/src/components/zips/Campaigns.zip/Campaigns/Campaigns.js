import React, { useState } from 'react';
import './Campaigns.css';
function Campaigns() {
  const [message, setMessage] = useState("");

  const messageTemplates = [
    "Welcome to our campaign! Let's make a difference together.",
    "Thank you for your support. We're excited to have you with us.",
    "Your feedback is valuable. Let us know how we can improve.",
    "Join us for upcoming events and stay connected!",
    "Don't miss out on our latest updates. Stay tuned!"
  ];

  const handleSave = () => {
    // Save message logic
    alert("Message saved!");
  };

  const handleCancel = () => {
    setMessage("");
  };

  const handleTemplateSelect = (template) => {
    setMessage(template);
  };

  return (
    <div className="campaign-main-content">
      <h2>Campaign Management Setup</h2>
      <label htmlFor="message">Pick up from Message Template</label>
      <div className="template-dropdown">
        <select onChange={(e) => handleTemplateSelect(e.target.value)} defaultValue="">
          <option value="" disabled>Select a template...</option>
          {messageTemplates.map((template, index) => (
            <option key={index} value={template}>
              {template}
            </option>
          ))}
        </select>
      </div>
      <textarea
        id="message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message here..."
      />
      <div className="button-group">
        <button onClick={handleSave} className="save-btn">Save</button>
        <button onClick={handleCancel} className="cancel-btn">Cancel</button>
      </div>
      
    </div>

   
  );
}

export default Campaigns;
