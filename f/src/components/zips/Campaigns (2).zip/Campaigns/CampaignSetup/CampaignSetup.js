import React, { useState, useEffect } from "react";
import "./CampaignSetup.css";
import config from "../../config";

const CampaignSetup = () => {
  const [campaignName, setCampaignName] = useState("");
  const [customerNames, setCustomerNames] = useState([]);
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [selectedNumbers, setSelectedNumbers] = useState([]);
  const [campaignId, setCampaignId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [numbersForCustomers, setNumbersForCustomers] = useState({});
  const [selectAllCustomers, setSelectAllCustomers] = useState(false); // To track the "Select All" checkbox for customers
  const [selectAllContacts, setSelectAllContacts] = useState(false); // To track the "Select All" checkbox for contacts

  const [scheduleDatetime, setScheduleDatetime] = useState(""); // Added state for schedule date and time

  useEffect(() => {
    const fetchCustomerNames = async () => {
      try {
        const response = await fetch(`${config.apiBaseUrl}/api/customers`);
        const data = await response.json();
        if (data && data.data) {
          setCustomerNames(data.data);
        } else {
          setError("Failed to load customer data.");
          setTimeout(() => setError(""), 3000);
        }
      } catch (error) {
        console.error("Error fetching customers:", error);
        setError("Error fetching customer data.");
        setTimeout(() => setError(""), 3000);
      }
    };

    fetchCustomerNames();
  }, []);

  useEffect(() => {
    const fetchCustomerNumbers = async () => {
      if (selectedCustomers.length === 0) return;

      const numbers = {};
      try {
        for (const customer of selectedCustomers) {
          const response = await fetch(
            `${config.apiBaseUrl}/api/customers/${customer}/numbers`
          );
          const data = await response.json();
          if (data && Array.isArray(data.data)) {
            numbers[customer] = data.data;
          } else {
            setError(`No valid numbers found for customer: ${customer}`);
            setTimeout(() => setError(""), 3000);
          }
        }
        setNumbersForCustomers(numbers);

        // Automatically select all numbers when fetched
        const allNumbers = Object.values(numbers)
          .flat()
          .map((number) => number.phoneNumber);
        setSelectedNumbers(allNumbers);
      } catch (error) {
        console.error("Error fetching numbers:", error);
        setError("Error fetching customer numbers.");
        setTimeout(() => setError(""), 3000);
      }
    };

    fetchCustomerNumbers();
  }, [selectedCustomers]);

  const handleCustomerSelection = (e) => {
    const { value, checked } = e.target;
    setSelectedCustomers((prev) => {
      let updatedSelection;
      if (checked) {
        updatedSelection = [...prev, value];
      } else {
        updatedSelection = prev.filter((customer) => customer !== value);
      }
      return updatedSelection;
    });
  };

  const handleNumberSelection = (e, phoneNumber) => {
    if (e.target.checked) {
      setSelectedNumbers((prev) => [...prev, phoneNumber]);
    } else {
      setSelectedNumbers((prev) => prev.filter((num) => num !== phoneNumber));
    }
  };

  // Handle Select All Customers
  const handleSelectAllCustomers = () => {
    setSelectAllCustomers((prev) => !prev);
    if (!selectAllCustomers) {
      setSelectedCustomers(customerNames.map((customer) => customer.customer_name));
    } else {
      setSelectedCustomers([]);
    }
  };

  // Handle Select All Contacts (Phone Numbers)
  const handleSelectAllContacts = () => {
    setSelectAllContacts((prev) => !prev);
    if (!selectAllContacts) {
      const allNumbers = Object.values(numbersForCustomers)
        .flat()
        .map((number) => number.phoneNumber);
      setSelectedNumbers(allNumbers);
    } else {
      setSelectedNumbers([]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (selectedNumbers.length === 0) {
      setError("Please select at least one phone number.");
      setTimeout(() => setError(""), 3000);
      setLoading(false);
      return;
    }

    const formattedNumbers = `{${selectedNumbers
      .map((num) => `"${num}"`)
      .join(",")}}`;

    try {
      const response = await fetch(`${config.apiBaseUrl}/api/campaigns`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          campaignName,
          selectedCustomers,
          selectedNumbers: formattedNumbers,
          scheduleDatetime, // Include schedule datetime
        }),
      });

      const data = await response.json();
      if (data && data.campaignId) {
        setCampaignId(data.campaignId);
        alert(`Campaign created successfully! Campaign ID: ${data.campaignId}`);
        setLoading(false);

        setTimeout(() => {
          setCampaignName("");
          setSelectedCustomers([]);
          setSelectedNumbers([]);
          setNumbersForCustomers({});
          setCampaignId("");
          setError("");
          setScheduleDatetime(""); // Reset the schedule datetime after submission
        }, 5000);
      } else {
        setError("Failed to create campaign");
        setTimeout(() => setError(""), 3000);
        setLoading(false);
      }
    } catch (error) {
      console.error("Error creating campaign:", error);
      setError("Error creating campaign.");
      setTimeout(() => setError(""), 3000);
      setLoading(false);
    }
  };

  return (
    <div className="campaign-setup-container">
      <h2 className="campaign-setup-header">Create Campaign</h2>
      {error && <div className="error-message">{error}</div>}
      <form className="campaign-setup-form" onSubmit={handleSubmit}>
        <div className="form_campaign_name">
          <label>Campaign Name</label>
          <input
            type="text"
            value={campaignName}
            onChange={(e) => setCampaignName(e.target.value)}
            required
          />
        </div>
        <div className="form_schedule_datetime">
          <label>Schedule Date and Time</label>
          <input
            type="datetime-local"
            value={scheduleDatetime}
            onChange={(e) => setScheduleDatetime(e.target.value)}
            required
          />
        </div>

        <div className="customers-data">
          <label>Customers</label>
          <table>
            <thead>
              <tr>
                <th>
                  <input
                    type="checkbox"
                    onChange={handleSelectAllCustomers}
                    checked={selectAllCustomers}
                  />
                  Select All
                </th>
                <th>Customer Name</th>
              </tr>
            </thead>
            <tbody>
              {customerNames.map((customer, index) => (
                <tr key={index}>
                  <td>
                    <input
                      type="checkbox"
                      value={customer.customer_name}
                      checked={selectedCustomers.includes(customer.customer_name)}
                      onChange={handleCustomerSelection}
                    />
                  </td>
                  <td>{customer.customer_name}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {Object.keys(numbersForCustomers).length > 0 && (
          <div>
            <h3>Customer Contacts</h3>
            <table>
              <thead>
                <tr>
                  <th>
                    <input
                      type="checkbox"
                      onChange={handleSelectAllContacts}
                      checked={selectAllContacts}
                    />
                    Select All
                  </th>
                  <th>Number</th>
                  <th>Customer Name</th>
                  <th>Name</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(numbersForCustomers).map(
                  ([customer, numbers]) =>
                    numbers.map((number, index) => (
                      selectedCustomers.includes(customer) && (
                        <tr key={`${customer}-${index}`}>
                          <td>
                            <input
                              type="checkbox"
                              checked={selectedNumbers.includes(number.phoneNumber)}
                              onChange={(e) =>
                                handleNumberSelection(e, number.phoneNumber)
                              }
                            />
                          </td>
                          <td>{number.phoneNumber}</td>
                          <td>{number.customerName}</td>
                          <td>{number.name}</td>
                        </tr>
                      )
                    ))
                )}
              </tbody>
            </table>
          </div>
        )}

        <div className="form_submit">
          <button type="submit" disabled={loading}>
            {loading ? "Creating..." : "Create Campaign"}
          </button>
        </div>
      </form>

      {campaignId && (
        <div className="success-message">
          Campaign created successfully! Campaign ID: {campaignId}
        </div>
      )}
    </div>
  );
};

export default CampaignSetup;
