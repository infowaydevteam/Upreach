import React, { useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import './CampaignCalendar.css';

const localizer = momentLocalizer(moment);

// Custom Toolbar Component to include only Month, Week, and Day options
const CustomToolbar = ({ label, onView, view }) => (
  <div className="custom-toolbar">
    <div className="custom-toolbar-label">{label}</div>
    <div className="custom-toolbar-views">

      <button
        className={`toolbar-btn ${view === 'week' ? 'active' : ''}`}
        onClick={() => onView('week')}
      >
        Week
      </button>
      <button
        className={`toolbar-btn ${view === 'day' ? 'active' : ''}`}
        onClick={() => onView('day')}
      >
        Day
      </button>
    </div>
  </div>
);

const CampaignCalendar = () => {
  const [events, setEvents] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState('Default Template');

  const handleSelectSlot = ({ start, end }) => {
    const template = prompt('Enter campaign template (e.g., Promo Email)');
    if (template) {
      setSelectedTemplate(template);
      const newEvent = {
        title: template,
        start,
        end,
        campaignTemplate: template,
      };
      setEvents([...events, newEvent]);
    }
  };

  const handleEventClick = (event) => {
    alert(
      `Campaign: ${event.title}\nStarts at: ${moment(event.start).format(
        'LLL'
      )}\nUsing Template: ${event.campaignTemplate}`
    );
  };

  return (
    <div className="campaign-calendar-container">
      <header className="calendar-header">
        <h2>Campaign Calendar</h2>
        <p>
          Plan, schedule, and manage your campaigns efficiently. Click on a time slot to create a new campaign.
        </p>
      </header>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        selectable
        style={{ height: '75vh' }}
        onSelectSlot={handleSelectSlot}
        onSelectEvent={handleEventClick}
        defaultView="week"
        views={['week', 'day']}
        popup
        components={{
          toolbar: (props) => (
            <CustomToolbar
              label={props.label}
              onView={props.onView}
              view={props.view}
            />
          ),
        }}
      />
    </div>
  );
};

export default CampaignCalendar;
