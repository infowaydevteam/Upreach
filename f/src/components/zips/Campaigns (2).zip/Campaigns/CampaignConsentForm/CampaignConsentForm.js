import React, { useState, useEffect } from 'react';
import './CampaignConsentForm.css';
import config from '../../config';

const CampaignConsentForm = () => {
  const [customerList, setCustomerList] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [consentAccepted, setConsentAccepted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await fetch(`${config.apiBaseUrl}/api/customers`);
        const data = await response.json();

        if (response.ok) {
          const customers = data.data.map((item) => item.customer_name);
          setCustomerList(customers);
          setLoading(false);
        } else {
          throw new Error(data.message || 'Failed to fetch customers');
        }
      } catch (err) {
        console.error('Error fetching customers:', err);
        setError(err.message);
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedCustomer || !consentAccepted) {
      alert('Please select a customer and accept the consent terms.');
      return;
    }

    alert(`Consent form accepted for ${selectedCustomer}`);
    setSelectedCustomer('');
    setConsentAccepted(false);
  };

  return (
    <div className="campaign-consent-form">
      <h3>Campaign Consent Form</h3>

      {loading ? (
        <p>Loading customers...</p>
      ) : error ? (
        <p className="error">Error: {error}</p>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="customer">Select Customer:</label>
            <select
              id="customer"
              name="customer"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
            >
              <option value="">-- Select a Customer --</option>
              {customerList.map((customer, index) => (
                <option key={index} value={customer}>
                  {customer}
                </option>
              ))}
            </select>
          </div>

          <div className="consent-text">
            <p>
              By accepting this form, you agree to allow us to send promotional campaigns to your contacts.
              Campaigns will be managed responsibly and within compliance with the applicable regulations.
              For more details, please contact our support team.
            </p>
          </div>

          <div className="form-group1">
            <label>
              <input
                type="checkbox"
                checked={consentAccepted}
                onChange={(e) => setConsentAccepted(e.target.checked)}
              />
              I accept the terms and conditions
            </label>
          </div>

          <div className="form-group">
            <button
              type="submit"
              disabled={!selectedCustomer || !consentAccepted}
              className="campaign-submit-button"
            >
              Submit Consent
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default CampaignConsentForm;
