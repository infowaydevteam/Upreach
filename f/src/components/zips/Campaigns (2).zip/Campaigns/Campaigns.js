import React, { useState, useEffect } from 'react';
import './Campaigns.css';
import config from '../config';
function Campaigns() {
  const [message, setMessage] = useState("");
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState("");

  const messageTemplates = [
    "Welcome to our campaign! Let's make a difference together.",
    "Thank you for your support. We're excited to have you with us.",
    "Your feedback is valuable. Let us know how we can improve.",
    "Join us for upcoming events and stay connected!",
    "Don't miss out on our latest updates. Stay tuned!"
  ];

  useEffect(() => {
    // Fetch campaigns from the backend when the component mounts
    const fetchCampaigns = async () => {
      try {
        const response = await fetch(`${config.apiBaseUrl}/api/campaigns1`);
        const data = await response.json();
        if (data && data.campaigns) {
          setCampaigns(data.campaigns);
        } else {
          console.log('No campaigns found');
        }
      } catch (error) {
        console.error('Error fetching campaigns:', error);
      }
    };

    fetchCampaigns();
  }, []);

  const handleSave = () => {
    // Save message logic
    alert("Message saved!");
  };

  const handleCancel = () => {
    setMessage("");
  };

  const handleTemplateSelect = (template) => {
    setMessage(template);
  };

  const handleCampaignSelect = (e) => {
    setSelectedCampaign(e.target.value);
  };

  return (
    <div className="campaign-main-content">
      <h2>Campaign Management Setup</h2>

      {/* Dropdown for selecting existing campaigns */}
      <label htmlFor="campaign">Select Existing Campaign</label>
      <div className="campaign-dropdown">
        <select
          id="campaign"
          onChange={handleCampaignSelect}
          value={selectedCampaign}
        >
          <option value="" disabled>Select a campaign...</option>
          {campaigns.length > 0 ? (
            campaigns.map((campaign) => (
              <option key={campaign.campaign_id} value={campaign.campaign_name}>
                {campaign.campaign_name}
              </option>
            ))
          ) : (
            <option disabled>No campaigns available</option>
          )}
        </select>
      </div>

      <label htmlFor="message">Pick up from Message Template</label>
      <div className="template-dropdown">
        <select onChange={(e) => handleTemplateSelect(e.target.value)} defaultValue="">
          <option value="" disabled>Select a template...</option>
          {messageTemplates.map((template, index) => (
            <option key={index} value={template}>
              {template}
            </option>
          ))}
        </select>
      </div>

      <textarea
        id="message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message here..."
      />

      <div className="button-group">
        <button onClick={handleSave} className="save-btn">Save</button>
        <button onClick={handleCancel} className="cancel-btn">Cancel</button>
      </div>
    </div>
  );
}

export default Campaigns;
